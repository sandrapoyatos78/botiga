export interface Ropa {
    id: string;
    tipo: string;
    precio: string;
    intercambio: [false]
 }


 export interface cliente {
    cid: string;
    nombre: string;
    email: string;
    pass: string;
    localizacion: string;
 }
 
 export interface User {
   uid: string;
   email: string;
   displayName: string;
 }
 