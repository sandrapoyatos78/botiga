export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCzanQ3MCR5Ly1_IjfFcK2PkzbB4ouvFNw",
    authDomain: "botiga-12e64.firebaseapp.com",
    projectId: "botiga-12e64",
    storageBucket: "botiga-12e64.appspot.com",
    messagingSenderId: "747952070160",
    appId: "1:747952070160:web:d4fc968a12e02c1b853495"
  }
};
