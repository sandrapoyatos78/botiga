// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  firebaseConfig: {
    apiKey: "AIzaSyCzanQ3MCR5Ly1_IjfFcK2PkzbB4ouvFNw",
    authDomain: "botiga-12e64.firebaseapp.com",
    projectId: "botiga-12e64",
    storageBucket: "botiga-12e64.appspot.com",
    messagingSenderId: "747952070160",
    appId: "1:747952070160:web:d4fc968a12e02c1b853495"
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
